package com.tms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;
@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {
	
	//TraineeBean bean2= new TraineeBean();
	
	@PersistenceContext
	private EntityManager entityManager;

	
	
	@Override
	public int addTrainee(TraineeBean traineeBean) throws TraineeException {
		int id=0;
		try {
			
			entityManager.persist(traineeBean);
			entityManager.flush();
			id=traineeBean.getTraineeId();
		} catch (Exception e) {
			
			throw new TraineeException("In Dao Layer Add Employee"+e.getMessage());
		}
		return id;
	}

	@Override
	public boolean deleteTrainee(int id) throws TraineeException {
		boolean isDeleted=false;
		TraineeBean bean = new TraineeBean();
	
		TraineeBean traineeBean= entityManager.find(TraineeBean.class,id);
		entityManager.remove(traineeBean);
		entityManager.flush();
		isDeleted= true;
		return isDeleted;
	}

	@Override
	public List<TraineeBean> viewAllTrainee() throws TraineeException {
		
		try {
			String qry="from TraineeBean";
			TypedQuery<TraineeBean> query=entityManager.createQuery(qry , TraineeBean.class);
			List<TraineeBean> list = query.getResultList();
			return list;
		} catch (Exception e) {
			throw new TraineeException ("In Dao Layer View All Trainee"+e.getMessage());
			
		}
	}

	@Override
	public TraineeBean searchTrainee(int id) throws TraineeException {
		TraineeBean traineeBean= new TraineeBean();
		traineeBean=entityManager.find(TraineeBean.class, id);
		return traineeBean;
	}

	@Override
	public boolean updateTraine(TraineeBean traineeBean)
			throws TraineeException {
		boolean isUpdated=false;
		entityManager.merge(traineeBean);
		entityManager.flush();
		isUpdated=true;
		
		
		return isUpdated;
	}

}
