package com.tms.dao;

import java.util.List;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;

public interface ITraineeDao {

	
	public int addTrainee(TraineeBean traineeBean) throws TraineeException;
	
	public boolean deleteTrainee(int id) throws TraineeException;
	
	public List<TraineeBean> viewAllTrainee() throws TraineeException;
	
	public TraineeBean searchTrainee(int id) throws TraineeException;
	
	public boolean updateTraine(TraineeBean traineeBean) throws TraineeException;
}
