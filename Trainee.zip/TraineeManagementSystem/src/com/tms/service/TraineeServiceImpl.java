package com.tms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tms.bean.TraineeBean;
import com.tms.dao.ITraineeDao;
import com.tms.dao.TraineeDaoImpl;
import com.tms.exception.TraineeException;

@Service
public class TraineeServiceImpl implements ITraineeService {
	@Autowired
	private ITraineeDao traineeDao;

	@Override
	public int addTrainee(TraineeBean traineeBean) throws TraineeException {
		
		return traineeDao.addTrainee(traineeBean);
	}

	@Override
	public boolean deleteTrainee(int id) throws TraineeException {
		
		return traineeDao.deleteTrainee(id);
	}

	@Override
	public List<TraineeBean> viewAllTrainee() throws TraineeException {
		
		return traineeDao.viewAllTrainee();
	}

	@Override
	public TraineeBean searchTrainee(int id) throws TraineeException {
		
		return traineeDao.searchTrainee(id);
	}

	@Override
	public boolean updateTraine(TraineeBean traineeBean)
			throws TraineeException {
		
		return traineeDao.updateTraine(traineeBean);
	}

}
