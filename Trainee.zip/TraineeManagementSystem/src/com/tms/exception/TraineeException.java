/**
 * 
 */
package com.tms.exception;

/**
 * @author avijisin
 *
 */
public class TraineeException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5786452055183282867L;

	public TraineeException(String message)
	{
		super(message);	
	}
	

}
