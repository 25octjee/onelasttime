package com.tms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.tms.bean.TraineeBean;
import com.tms.exception.TraineeException;
import com.tms.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	private ITraineeService traineeService;
	
	@RequestMapping("showHomePage")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("add")
	public String showAddPage()
	{
		return("addTrainee");
	}
	@RequestMapping(value="addTrainee", method=RequestMethod.POST)
	public ModelAndView addTrainee(@ModelAttribute("trainee") TraineeBean traineeBean,
BindingResult result)
	{
		
		
		ModelAndView mv= new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "In Add Trainee Binding Result");
		} else
			try {
				int id = traineeService.addTrainee(traineeBean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("trainee", traineeBean);
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		
		
		
		
		return mv;
	}
	@RequestMapping("showAll")
	public ModelAndView showAll()
	{
		ModelAndView mv= new ModelAndView();
		try {
			List<TraineeBean> list= traineeService.viewAllTrainee();
			mv.setViewName("viewAll");
			mv.addObject("list", list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message","Show All Error");
			
		}
		
		return mv;
	}
	@RequestMapping("delete")
	public String delete()
	{
		return("deleteActual");
	}
	
	@RequestMapping("deleteActual")
	public ModelAndView deleteActual(@RequestParam("traineeId")  int id)
	{
		ModelAndView mv= new ModelAndView();
		try {
			boolean isDeleted=false;
			isDeleted=traineeService.deleteTrainee(id);
			isDeleted=true;
			mv.addObject("isDeleted", isDeleted);
			List<TraineeBean> list= traineeService.viewAllTrainee();
			mv.setViewName("viewAll");
			mv.addObject("list", list);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message","In delete Method");
		}
		
		
		return mv;
		
	}
	@RequestMapping("search")
	public String search()
	{
		return("searchActual");
	}
	
	@RequestMapping("searchActual")
	public ModelAndView searchTraine(@RequestParam("traineeId") int id)
	{
		ModelAndView mv = null;
		try {
			TraineeBean traineeBean = new TraineeBean();
			mv = new ModelAndView();
			traineeBean=traineeService.searchTrainee(id);
			mv.setViewName("searchOne");
			mv.addObject("traineeBean", traineeBean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", "In Search Actual Error occur");
		}
		return mv;
		
	}
	
	@RequestMapping("update")
	public String update()
	{
		
		
		return ("updateMiddle");
		
	}
	
	@RequestMapping("updateActual")
	public ModelAndView updateTraineeMid(@RequestParam("traineeId") int id)
	{
		ModelAndView mv = null;
		try {
			TraineeBean traineeBean = new TraineeBean();
			mv = new ModelAndView();
			traineeBean=traineeService.searchTrainee(id);
			mv.setViewName("updateActual");
			mv.addObject("traineeBean", traineeBean);
		} catch (TraineeException e) {
			mv.setViewName("error");
			mv.addObject("message", "In Search Actual Error occur");
		}
		return mv;
		
	}
	
	@RequestMapping("successUpdate")
	public ModelAndView updateTrainee(@ModelAttribute("trainee") TraineeBean traineeBean, BindingResult result)
	{
		ModelAndView mv= new ModelAndView();
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "On Actual Update");
		}
		else
		{
			try {
				traineeService.updateTraine(traineeBean);
				mv.setViewName("successUpdate");
				mv.addObject("traineeBean",traineeBean );
			} catch (TraineeException e) {
				mv.setViewName("error");
				mv.addObject("message", "Update has Done");
			}
			
		}
		return mv;
		
		
	}
	
	
}
