package com.cg.exception;

public class TmsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8935365484487549030L;

	public TmsException() {
		super();
		
	}

	public TmsException(String message) {
		super(message);
		
	}
	
	
}
