package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class TraineeBean {
	
	@Id
	@Column(name="traineeId")
	private int traineeId;
	@Column(name="traineeName",length=30)
	private String traineeName;
	@Column(name="traineeLocation",length=20)
	private String traineeLocation;
	@Column(name="traineeDomain",length=20)
	private String traineeDomain;
	
	public TraineeBean() {
		super();
	}
	public TraineeBean(int traineeId, String traineeName,
			String traineeLocation, String traineeDomain) {
		super();
		this.traineeId = traineeId;
		this.traineeName = traineeName;
		this.traineeLocation = traineeLocation;
		this.traineeDomain = traineeDomain;
	}
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	@Override
	public String toString() {
		return "TraineeBean [traineeId=" + traineeId + ", traineeName="
				+ traineeName + ", traineeLocation=" + traineeLocation
				+ ", traineeDomain=" + traineeDomain + "]";
	}
	
	
	
}
