package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.bean.TraineeBean;
import com.cg.exception.TmsException;
import com.cg.service.ITraineeService;

@Controller
public class TraineeContoller {
	
	@Autowired
	ITraineeService traineeService;



	public ITraineeService getItrainee() {
		return traineeService;
	}

	public void setItrainee(ITraineeService traineeService) {
		this.traineeService = traineeService;
	}
	
	@RequestMapping("/home")
	public String home()
	{
		return ("index");
	}
	
	@RequestMapping("/add")
	public String addT()
	{
		return ("addtrainee");
	}
	
	@RequestMapping("/insert")
	public ModelAndView insertTrainee(@ModelAttribute("traineeBean")TraineeBean bean)
	{	ModelAndView mv = new ModelAndView();
		
		try {
			traineeService.addTrainee(bean);
			//mv.addObject("bean", bean);
			mv.setViewName("success");
			mv.addObject("tBean", bean);
			mv.addObject("message", "Trainee Added Sucessfully");
		} catch (TmsException e) {
			System.out.println("Trainee addition exception ");
			mv.addObject("message","Trainee addition exception ");
			mv.setViewName("error");
		}
		
		System.out.println("Added successfully");
		return (mv);
	}
	
	@RequestMapping("/get")
	public ModelAndView showViewTraineeForm() {

		// Create an attribute of type Question
		TraineeBean tBean = new TraineeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewTrainee");
		mv.addObject("trainee", tBean);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/viewTrainee")
	public ModelAndView viewTrainee(@ModelAttribute("trainee") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();

		TraineeBean tBean = new TraineeBean();
		try {
			tBean = traineeService.getTrainee(bean.getTraineeId());
			if (tBean != null) {
				mv.setViewName("viewTrainee");
				mv.addObject("tBean", tBean);
				//mv.addObject("isFirst", "false");
			} else {
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("message", msg);
			}
		} catch (TmsException e) {
			String msg = "Exception thrown in viewTrainee";
			mv.setViewName("error");
			mv.addObject("message", msg);
		}

		return mv;
	}
	
	@RequestMapping("/getAll")
	public ModelAndView showViewAll() {

		// Create an attribute of type Question
		List<TraineeBean> list = new ArrayList<TraineeBean>();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("viewTrainee");
		
		try {
			list = traineeService.getAll();
			if (list != null) {
				mv.setViewName("viewAll");
				mv.addObject("list", list);
				//mv.addObject("isFirst", "false");
			} else {
				String msg = "No trainee info available";
				mv.setViewName("error");
				mv.addObject("message", msg);
			}
		} catch (TmsException e) {
			String msg = "Exception thrown in viewTrainee";
			mv.setViewName("error");
			mv.addObject("message", msg);
		}

		return mv;
	}
	
	
	@RequestMapping("/delete")
	public ModelAndView showDeleteTraineeForm() {

		// Create an attribute of type Question
		TraineeBean tBean = new TraineeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("deleteTrainee");
		mv.addObject("trainee", tBean);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/deleteTrainee")
	public ModelAndView deleteTrainee(@ModelAttribute("trainee") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();

		TraineeBean tBean = new TraineeBean();
		try {
			tBean = traineeService.getTrainee(bean.getTraineeId());
			if (tBean != null) {
				mv.setViewName("deleteTrainee");
				mv.addObject("tBean", tBean);
				//mv.addObject("isFirst", "false");
			} else {
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("message", msg);
			}
		} catch (TmsException e) {
			String msg = "Exception thrown in viewTrainee";
			mv.setViewName("error");
			mv.addObject("message", msg);
		}

		return mv;
	}
	
	@RequestMapping("/finaldelete")
	public ModelAndView finaldelete(@RequestParam("id")int traineeId) {

		ModelAndView mv = new ModelAndView();

		TraineeBean tBean = new TraineeBean();
		try {
			tBean = traineeService.deleteTrainee(traineeId);
			if (tBean != null) {
				mv.setViewName("success");
				mv.addObject("tBean", tBean);
				mv.addObject("message", "Trainee Deleted Sucessfully");
				
			} else {
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("message", msg);
			}
		} catch (TmsException e) {
			String msg = "Exception thrown in viewTrainee";
			mv.setViewName("error");
			mv.addObject("message", msg);
		}

		return mv;
	}
	
	
	
	
	@RequestMapping("/modify")
	public ModelAndView showModifyTraineeForm() {

		// Create an attribute of type Question
		TraineeBean tBean = new TraineeBean();
		// Add the attribute to the model and return along with
		// the view name
		ModelAndView mv = new ModelAndView("modifyTrainee");
		mv.addObject("trainee", tBean);
		mv.addObject("isFirst", "true");

		return mv;
	}
	
	@RequestMapping("/modifyTrainee")
	public ModelAndView modifyTrainee(@ModelAttribute("trainee") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();

		TraineeBean tBean = new TraineeBean();
		try {
			tBean = traineeService.getTrainee(bean.getTraineeId());
			if (tBean != null) {
				mv.setViewName("modifyTrainee");
				mv.addObject("tBean", tBean);
				//mv.addObject("isFirst", "false");
			} else {
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("message", msg);
			}
		} catch (TmsException e) {
			String msg = "Exception thrown in viewTrainee";
			mv.setViewName("error");
			mv.addObject("message", msg);
		}

		return mv;
	}
	
	@RequestMapping("/finalmodify")
	public ModelAndView finalmodify(@ModelAttribute("trainee2") TraineeBean bean) {

		ModelAndView mv = new ModelAndView();

		TraineeBean tBean = new TraineeBean();
		try {
			tBean = traineeService.updateTrainee(bean);
			if (tBean != null) {
				mv.setViewName("success");
				mv.addObject("tBean", tBean);
				mv.addObject("message", "Trainee updated Sucessfully");
				
			} else {
				String msg = "Enter a Valid Id!!";
				mv.setViewName("error");
				mv.addObject("message", msg);
			}
		} catch (TmsException e) {
			String msg = "Exception thrown in viewTrainee";
			mv.setViewName("error");
			mv.addObject("message", msg);
		}

		return mv;
	}
	
}
