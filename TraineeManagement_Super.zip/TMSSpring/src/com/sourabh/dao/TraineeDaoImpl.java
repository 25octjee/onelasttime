package com.sourabh.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.sourabh.bean.TraineeBean;
import com.sourabh.exception.TmsException;

@Repository
@Transactional
public class TraineeDaoImpl implements ITraineeDao {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void addTrainee(TraineeBean bean) throws TmsException {
		
		try {
			entityManager.persist(bean);
			entityManager.flush();
		} catch (Exception e) {
			throw new TmsException("Exception in addTrainee in dao layer "+e.getMessage());
		}
		
	}

	@Override
	public TraineeBean getTrainee(int traineeId) throws TmsException {
		
		TraineeBean bean;
		try {
			bean = entityManager.find(TraineeBean.class, traineeId);
		} catch (Exception e) {
			throw new TmsException("Exception in getTrainee in dao layer "+e.getMessage());
		}
		
		return bean;
	}

	@Override
	public List<TraineeBean> getAll() throws TmsException {
		List<TraineeBean> list =null;
		try {
			TypedQuery<TraineeBean> qry = entityManager.createQuery("from TraineeBean", TraineeBean.class);
			list = qry.getResultList();
		} catch (Exception e) {
			throw new TmsException("Exception in getAllTrainees in dao layer "+e.getMessage() );
		}
		
		return list;
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) throws TmsException {
		try {
			TraineeBean trainee = entityManager.find(TraineeBean.class, traineeId);
			if(trainee!=null)
			{
				entityManager.remove(trainee);		
				return trainee;
			}
		} catch (Exception e) {
			throw new TmsException("Exception in deleteTrainee in dao layer "+e.getMessage() );
		}
		return null;
	}

	@Override
	public TraineeBean updateTrainee(TraineeBean bean)
			throws TmsException {
		try {
			TraineeBean trainee = entityManager.find(TraineeBean.class, bean.getTraineeId());
			if(trainee!=null)
			{
				entityManager.merge(bean);
				System.out.println(trainee);
				return trainee;
			}
		} catch (Exception e) {
			throw new TmsException("Exception in updateTrainee in dao layer "+e.getMessage() );
		}
		return null;
	}
	


}
