package com.sourabh.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sourabh.bean.TraineeBean;
import com.sourabh.dao.ITraineeDao;
import com.sourabh.exception.TmsException;

@Service
public class TraineeServiceImpl implements ITraineeService {
	
	@Autowired
	ITraineeDao tdao;

	@Override
	public void addTrainee(TraineeBean bean) throws TmsException {
		tdao.addTrainee(bean);
		
	}

	@Override
	public TraineeBean getTrainee(int traineeId) throws TmsException {
		
		return tdao.getTrainee(traineeId);
	}

	@Override
	public List<TraineeBean> getAll() throws TmsException {
		
		return tdao.getAll();
	}

	@Override
	public TraineeBean deleteTrainee(int traineeId) throws TmsException {
		
		return tdao.deleteTrainee(traineeId);
	}

	@Override
	public TraineeBean updateTrainee(TraineeBean bean) throws TmsException {
		
		return tdao.updateTrainee(bean);
	}




}
