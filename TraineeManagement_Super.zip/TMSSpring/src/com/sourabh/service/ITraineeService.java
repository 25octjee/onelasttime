package com.sourabh.service;

import java.util.List;

import com.sourabh.bean.TraineeBean;
import com.sourabh.exception.TmsException;

public interface ITraineeService {
	
	public void addTrainee(TraineeBean bean)throws TmsException;
	
	public TraineeBean getTrainee(int traineeId)throws TmsException;
	
	public List<TraineeBean> getAll()throws TmsException;
	
	public TraineeBean deleteTrainee(int traineeId)throws TmsException;
	
	public TraineeBean updateTrainee(TraineeBean bean)throws TmsException;
}
